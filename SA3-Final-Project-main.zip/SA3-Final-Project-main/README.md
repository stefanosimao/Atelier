# SA3-Final-Project
Repository for the Final Project of Software Atelier 3 - USIhoot

Students:

    - Catarina Carvalho Morais

    - Stefano Gonçalves Simao

    - Lovnesh Bhardwaj

    - Andrea Michele Zucchi

    - Alessio Cordivani
    
    - Brian Bronz

